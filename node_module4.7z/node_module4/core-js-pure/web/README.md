This folder contains entry points for features from [WHATWG / W3C](https://github.com/zloirock/core-js/tree/v3#web-standards) with dependencies.
