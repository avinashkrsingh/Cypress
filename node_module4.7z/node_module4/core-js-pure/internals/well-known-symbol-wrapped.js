var wellKnownSymbol = require('../internals/well-known-symbol');

exports.f = wellKnownSymbol;
