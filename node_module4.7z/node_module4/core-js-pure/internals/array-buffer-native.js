module.exports = typeof ArrayBuffer !== 'undefined' && typeof DataView !== 'undefined';
