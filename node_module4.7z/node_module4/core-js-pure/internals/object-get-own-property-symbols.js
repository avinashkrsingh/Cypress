exports.f = Object.getOwnPropertySymbols;
