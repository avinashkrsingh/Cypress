var global = require('../internals/global');

module.exports = global.Promise;
