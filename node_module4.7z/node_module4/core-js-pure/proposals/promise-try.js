require('../modules/esnext.promise.try');
