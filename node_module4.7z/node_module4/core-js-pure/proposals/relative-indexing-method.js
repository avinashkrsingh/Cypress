// https://github.com/tc39/proposal-relative-indexing-method
require('../modules/esnext.array.at');
// TODO: disabled by default because of the conflict with another proposal
// require('../modules/esnext.string.at-alternative');
require('../modules/esnext.typed-array.at');
