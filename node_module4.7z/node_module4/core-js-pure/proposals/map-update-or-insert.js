// TODO: remove from `core-js@4`
require('./map-upsert');
