require('../modules/esnext.array.is-template-object');
