require('./es');
require('./proposals');
require('./web');
var path = require('./internals/path');

module.exports = path;
