# @svgr/babel-plugin-svg-dynamic-title

## Install

```
npm install --save-dev @svgr/babel-plugin-svg-dynamic-title
```

## Usage

**.babelrc**

```json
{
  "plugins": ["@svgr/babel-plugin-svg-dynamic-title"]
}
```

## License

MIT
