# @svgr/babel-preset

## Install

```
npm install --save-dev @svgr/babel-preset
```

## Usage

**.babelrc**

```json
{
  "presets": [["@svgr/babel-preset", { "svgProps": { "width": 200 } }]]
}
```

## License

MIT
