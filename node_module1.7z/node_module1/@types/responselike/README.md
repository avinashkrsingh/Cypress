# Installation
> `npm install --save @types/responselike`

# Summary
This package contains type definitions for responselike ( https://github.com/lukechilds/responselike#readme ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/responselike

Additional Details
 * Last updated: Wed, 30 Jan 2019 18:47:32 GMT
 * Dependencies: @types/node
 * Global values: none

# Credits
These definitions were written by BendingBender <https://github.com/BendingBender>.
