# Installation
> `npm install --save @types/json-schema`

# Summary
This package contains type definitions for json-schema 4.0, 6.0 and (https://github.com/kriszyp/json-schema).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/json-schema.

### Additional Details
 * Last updated: Tue, 19 Jan 2021 23:09:28 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Boris Cherny](https://github.com/bcherny), [Cyrille Tuzi](https://github.com/cyrilletuzi), [Lucian Buzzo](https://github.com/lucianbuzzo), [Roland Groza](https://github.com/rolandjitsu), and [Jason Kwok](https://github.com/JasonHK).
