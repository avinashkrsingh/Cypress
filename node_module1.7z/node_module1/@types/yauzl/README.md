# Installation
> `npm install --save @types/yauzl`

# Summary
This package contains type definitions for yauzl (https://github.com/thejoshwolfe/yauzl).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/yauzl

Additional Details
 * Last updated: Wed, 02 Jan 2019 20:27:45 GMT
 * Dependencies: @types/node
 * Global values: none

# Credits
These definitions were written by Florian Keller <https://github.com/ffflorian>.
