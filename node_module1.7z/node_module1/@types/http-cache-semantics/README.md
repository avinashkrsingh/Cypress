# Installation
> `npm install --save @types/http-cache-semantics`

# Summary
This package contains type definitions for http-cache-semantics ( https://github.com/kornelski/http-cache-semantics#readme ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/http-cache-semantics

Additional Details
 * Last updated: Wed, 30 Jan 2019 18:47:31 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by BendingBender <https://github.com/BendingBender>.
