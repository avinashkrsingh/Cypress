module.exports = function _btoa(str) {
  return btoa(str)
}
